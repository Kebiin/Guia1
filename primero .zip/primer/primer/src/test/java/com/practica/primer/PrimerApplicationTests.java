package com.practica.primer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerApplicationTests {

	@Test
	void contextLoads() {
	}

}
